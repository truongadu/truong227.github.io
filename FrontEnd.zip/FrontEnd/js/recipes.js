loadRecipes();

async function loadRecipes() {

    const response = await fetch(
        "http://localhost:5206/api/recipes");

    const recipes = await response.json();

    let html = "";

    recipes.forEach(recipe => {

        html += `
        <div>
            <h3>${recipe.recipeName}</h3>
            <p>${recipe.description}</p>

            <button onclick="addFavorite(${recipe.recipeId})">
                ❤️ Yêu thích
            </button>

            <hr>
        </div>
        `;
    });

    document.getElementById("recipes").innerHTML = html;
}

async function addFavorite(recipeId) {

    const userId =
        localStorage.getItem("userId");

    await fetch(
        "http://localhost:5206/api/favorites",
        {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                userId: userId,
                recipeId: recipeId
            })
        });

    alert("Đã thêm yêu thích");
}