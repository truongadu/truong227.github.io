async function login() {

    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    const response = await fetch(
        "http://localhost:5206/api/auth/login",
        {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                email,
                password
            })
        });

    const data = await response.json();

    localStorage.setItem("token", data.token);
    localStorage.setItem("userId", data.userId);

    alert("Đăng nhập thành công");

    window.location.href = "index.html";
}