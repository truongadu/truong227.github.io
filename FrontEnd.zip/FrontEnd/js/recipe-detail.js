const recipeId =
    new URLSearchParams(window.location.search)
        .get("id");
        
loadRecipe();
loadComments();
loadRating();

async function loadRecipe() {

    const response =
        await fetch(
            `http://localhost:5206/api/recipes/${recipeId}`);

    const recipe =
        await response.json();

    document.getElementById("recipeName")
        .innerText = recipe.recipeName;

    document.getElementById("description")
        .innerText = recipe.description;

    document.getElementById("cookingTime")
        .innerText = recipe.cookingTime;
}

async function loadComments() {

    const response =
        await fetch(
            `http://localhost:5206/api/comments/recipe/${recipeId}`);

    const comments =
        await response.json();

    let html = "";

    comments.forEach(comment => {

        html += `
            <div class="comment-item">
                <p>${comment.content}</p>
            </div>
        `;
    });

    document.getElementById("comments")
        .innerHTML = html;
}

async function addComment() {

    const userId =
        localStorage.getItem("userId") || 1;

    const content =
        document.getElementById("commentContent").value;

    const response =
        await fetch(
            "http://localhost:5206/api/comments",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    userId,
                    recipeId,
                    content
                })
            });

    if (response.ok)
    {
        document.getElementById("commentContent")
            .value = "";

        loadComments();
    }
}

async function rateRecipe(score) {

    const userId =
        localStorage.getItem("userId") || 1;

    const response =
        await fetch(
            "http://localhost:5206/api/ratings",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    userId,
                    recipeId,
                    score
                })
            });

    if (response.ok)
    {
        alert("Đánh giá thành công");

        loadRating();
    }
}

async function loadRating() {

    const response =
        await fetch(
            `http://localhost:5206/api/ratings/recipe/${recipeId}`);

    const data =
        await response.json();

    document.getElementById("averageRating")
        .innerText =
        `Điểm trung bình: ${data.averageRating}`;
}