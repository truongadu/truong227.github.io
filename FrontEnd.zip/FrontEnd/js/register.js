async function register() {

    const response = await fetch(
        "http://localhost:5206/api/auth/register",
        {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                fullName: document.getElementById("fullName").value,
                email: document.getElementById("email").value,
                password: document.getElementById("password").value
            })
        });

    const data = await response.json();

    alert(data.message);
}