loadFavorites();

async function loadFavorites() {

    const userId =
        localStorage.getItem("userId");

    const response = await fetch(
        `http://localhost:5206/api/favorites/user/${userId}`);

    const favorites = await response.json();

    document.getElementById("favorites")
        .innerHTML =
        JSON.stringify(favorites, null, 2);
}