loadProfile();

async function loadProfile() {

    const userId =
        localStorage.getItem("userId");

    const response =
        await fetch(
            `http://localhost:5206/api/users/${userId}`);

    const user =
        await response.json();

    document.getElementById("fullName")
        .innerText =
        user.fullName;

    document.getElementById("email")
        .innerText =
        user.email;
///log out
function logout() {

    localStorage.removeItem("token");

    localStorage.removeItem("userId");

    alert("Đăng xuất thành công");

    window.location.href =
        "login.html";
}
}