import Link from 'next/link'
import Image from 'next/image'
import { ArrowLeft } from 'lucide-react'
import { Logo } from '@/components/brand/logo'

interface AuthLayoutProps {
  title: string
  subtitle: string
  children: React.ReactNode
  backHref?: string
}

export function AuthLayout({
  title,
  subtitle,
  children,
  backHref = '/',
}: AuthLayoutProps) {
  return (
    <main className="flex min-h-screen flex-col lg:flex-row">
      {/* Cột hình ảnh - chỉ hiện trên màn lớn */}
      <aside className="relative hidden lg:flex lg:w-1/2">
        <Image
          src="/images/auth-food.png"
          alt="Đôi tay đang sơ chế rau củ tươi trong căn bếp ấm cúng"
          fill
          priority
          className="object-cover"
        />
        <div
          className="absolute inset-0 bg-gradient-to-t from-foreground/60 via-foreground/20 to-transparent"
          aria-hidden="true"
        />
        <div className="absolute inset-x-0 bottom-0 p-12">
          <p className="max-w-sm text-balance font-heading text-3xl font-bold leading-snug text-card">
            Gian bếp của bạn, nguồn cảm hứng bất tận.
          </p>
        </div>
      </aside>

      {/* Cột form */}
      <section className="flex w-full flex-col px-6 py-10 lg:w-1/2 lg:px-16 lg:py-12">
        <div className="flex items-center justify-between">
          <Logo />
          <Link
            href={backHref}
            className="flex items-center gap-1.5 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
          >
            <ArrowLeft className="size-4" aria-hidden="true" />
            Quay lại
          </Link>
        </div>

        <div className="mx-auto flex w-full max-w-sm flex-1 flex-col justify-center py-10">
          <header className="mb-8">
            <h1 className="font-heading text-3xl font-bold text-foreground">
              {title}
            </h1>
            <p className="mt-2 text-pretty leading-relaxed text-muted-foreground">
              {subtitle}
            </p>
          </header>
          {children}
        </div>
      </section>
    </main>
  )
}
