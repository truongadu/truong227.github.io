import { ChefHat } from 'lucide-react'
import { cn } from '@/lib/utils'

interface LogoProps {
  className?: string
  showText?: boolean
  textClassName?: string
}

export function Logo({ className, showText = true, textClassName }: LogoProps) {
  return (
    <div className={cn('flex items-center gap-2.5', className)}>
      <span className="flex size-9 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-sm">
        <ChefHat className="size-5" aria-hidden="true" />
      </span>
      {showText && (
        <span
          className={cn(
            'font-heading text-xl font-bold tracking-tight text-foreground',
            textClassName,
          )}
        >
          Ngon<span className="text-primary">Bep</span>
        </span>
      )}
    </div>
  )
}
