import Link from 'next/link'
import { User, Mail, Lock } from 'lucide-react'
import { AuthLayout } from '@/components/auth/auth-layout'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'

export default function RegisterPage() {
  return (
    <AuthLayout
      title="Tạo tài khoản mới"
      subtitle="Tham gia cùng cộng đồng yêu bếp và bắt đầu hành trình nấu ăn của bạn."
    >
      <form className="flex flex-col gap-5">
        <div className="flex flex-col gap-2">
          <Label htmlFor="name">Họ và tên</Label>
          <div className="relative">
            <User
              className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
              aria-hidden="true"
            />
            <Input
              id="name"
              type="text"
              placeholder="Nguyễn Văn A"
              autoComplete="name"
              className="h-12 rounded-xl pl-10"
            />
          </div>
        </div>

        <div className="flex flex-col gap-2">
          <Label htmlFor="email">Email</Label>
          <div className="relative">
            <Mail
              className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
              aria-hidden="true"
            />
            <Input
              id="email"
              type="email"
              placeholder="ban@email.com"
              autoComplete="email"
              className="h-12 rounded-xl pl-10"
            />
          </div>
        </div>

        <div className="flex flex-col gap-2">
          <Label htmlFor="password">Mật khẩu</Label>
          <div className="relative">
            <Lock
              className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
              aria-hidden="true"
            />
            <Input
              id="password"
              type="password"
              placeholder="Ít nhất 8 ký tự"
              autoComplete="new-password"
              className="h-12 rounded-xl pl-10"
            />
          </div>
        </div>

        <label className="flex items-start gap-2.5 text-sm text-muted-foreground">
          <input
            type="checkbox"
            className="mt-0.5 size-4 rounded border-border accent-primary"
          />
          <span>
            Tôi đồng ý với{' '}
            <Link href="#" className="font-medium text-primary hover:underline">
              Điều khoản
            </Link>{' '}
            và{' '}
            <Link href="#" className="font-medium text-primary hover:underline">
              Chính sách bảo mật
            </Link>
          </span>
        </label>

        <Button
          type="submit"
          size="lg"
          className="mt-1 h-12 rounded-full text-base font-semibold"
        >
          Đăng ký
        </Button>
      </form>

      <p className="mt-8 text-center text-sm text-muted-foreground">
        Đã có tài khoản?{' '}
        <Link
          href="/login"
          className="font-semibold text-primary hover:underline"
        >
          Đăng nhập
        </Link>
      </p>
    </AuthLayout>
  )
}
