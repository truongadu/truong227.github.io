import Link from 'next/link'
import Image from 'next/image'
import { ArrowRight } from 'lucide-react'
import { Logo } from '@/components/brand/logo'
import { Button } from '@/components/ui/button'

export default function SplashPage() {
  return (
    <main className="relative flex min-h-screen flex-col overflow-hidden bg-background">
      {/* Hình ảnh món ăn nền */}
      <div className="relative flex-1">
        <Image
          src="/images/splash-food.png"
          alt="Mâm cơm với rau củ tươi và món ăn tự nấu hấp dẫn"
          fill
          priority
          className="object-cover"
        />
        <div
          className="absolute inset-0 bg-gradient-to-b from-foreground/20 via-foreground/10 to-background"
          aria-hidden="true"
        />

        {/* Logo trên cùng */}
        <div className="absolute inset-x-0 top-0 flex justify-center pt-12">
          <Logo textClassName="text-2xl text-card drop-shadow" />
        </div>
      </div>

      {/* Nội dung dưới cùng */}
      <section className="relative z-10 -mt-16 rounded-t-[2.5rem] bg-background px-6 pb-12 pt-10">
        <div className="mx-auto flex w-full max-w-md flex-col items-center text-center">
          <span className="mb-4 inline-flex items-center rounded-full bg-accent px-4 py-1.5 text-xs font-semibold uppercase tracking-wide text-accent-foreground">
            Hơn 10.000 công thức
          </span>

          <h1 className="text-balance font-heading text-4xl font-bold leading-tight text-foreground">
            Nấu ăn ngon mỗi ngày thật dễ dàng
          </h1>

          <p className="mt-4 text-pretty leading-relaxed text-muted-foreground">
            Khám phá hàng ngàn công thức món ngon, lên thực đơn và nấu nướng tự
            tin ngay tại căn bếp của bạn.
          </p>

          <div className="mt-8 flex w-full flex-col gap-3">
            <Button
              render={<Link href="/register" />}
              nativeButton={false}
              size="lg"
              className="h-12 rounded-full text-base font-semibold"
            >
              Bắt đầu ngay
              <ArrowRight className="size-4" aria-hidden="true" />
            </Button>
            <Button
              render={<Link href="/login" />}
              nativeButton={false}
              variant="ghost"
              size="lg"
              className="h-12 rounded-full text-base font-semibold text-foreground hover:bg-secondary"
            >
              Tôi đã có tài khoản
            </Button>
          </div>
        </div>
      </section>
    </main>
  )
}
