using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CookingApp.API.Data;
using CookingApp.API.Models;

namespace CookingApp.API.Controllers;

[ApiController]
[Route("api/recipeingredients")]
public class RecipeIngredientsController : ControllerBase
{
    private readonly CookingAppDbContext _context;

    public RecipeIngredientsController(CookingAppDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        return Ok(await _context.RecipeIngredients.ToListAsync());
    }

    [HttpPost]
    public async Task<IActionResult> Create(RecipeIngredient item)
    {
        _context.RecipeIngredients.Add(item);
        await _context.SaveChangesAsync();

        return Ok(item);
    }
}