using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using CookingApp.API.Data;
using CookingApp.API.Models;

namespace CookingApp.API.Controllers;

//[Authorize]
[ApiController]
[Route("api/favorites")]
public class FavoritesController : ControllerBase
{
    private readonly CookingAppDbContext _context;

    public FavoritesController(CookingAppDbContext context)
    {
        _context = context;
    }

    // GET ALL
    [HttpGet]
    public async Task<IActionResult> GetFavorites()
    {
        var favorites = await _context.Favorites.ToListAsync();
        return Ok(favorites);
    }

    // GET BY USER
    [HttpGet("user/{userId}")]
    public async Task<IActionResult> GetUserFavorites(int userId)
    {
        var favorites = await _context.Favorites
            .Where(f => f.UserId == userId)
            .ToListAsync();

        return Ok(favorites);
    }

    // CREATE
    [HttpPost]
    public async Task<IActionResult> AddFavorite([FromBody] Favorite favorite)
    {
        favorite.CreatedAt = DateTime.Now;

        _context.Favorites.Add(favorite);
        await _context.SaveChangesAsync();

        return Ok(favorite);
    }

    // DELETE
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteFavorite(int id)
    {
        var favorite = await _context.Favorites.FindAsync(id);

        if (favorite == null)
            return NotFound();

        _context.Favorites.Remove(favorite);

        await _context.SaveChangesAsync();

        return NoContent();
    }
}