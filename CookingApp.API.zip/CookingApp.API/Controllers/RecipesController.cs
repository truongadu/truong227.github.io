using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CookingApp.API.Data;
using CookingApp.API.Models;
using Microsoft.AspNetCore.Authorization;
namespace CookingApp.API.Controllers;

//[Authorize]
[ApiController]
[Route("api/recipes")]
public class RecipesController : ControllerBase
{
    private readonly CookingAppDbContext _context;

    public RecipesController(CookingAppDbContext context)
    {
        _context = context;
    }

    // GET ALL
    [HttpGet]
    public async Task<IActionResult> GetRecipes()
    {
        var recipes = await _context.Recipes.ToListAsync();
        return Ok(recipes);
    }

    // GET BY ID
    [HttpGet("{id}")]
    public async Task<IActionResult> GetRecipe(int id)
    {
        var recipe = await _context.Recipes.FindAsync(id);

        if (recipe == null)
            return NotFound();

        return Ok(recipe);
    }

    // CREATE
    [HttpPost]
    public async Task<IActionResult> CreateRecipe([FromBody] Recipe recipe)
    {
        _context.Recipes.Add(recipe);
        await _context.SaveChangesAsync();

        return Ok(recipe);
    }

    // UPDATE
    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateRecipe(int id, [FromBody] Recipe recipe)
    {
        if (id != recipe.RecipeId)
            return BadRequest();

        _context.Entry(recipe).State = EntityState.Modified;
        await _context.SaveChangesAsync();

        return NoContent();
    }

    // DELETE
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteRecipe(int id)
    {
        var recipe = await _context.Recipes.FindAsync(id);

        if (recipe == null)
            return NotFound();

        _context.Recipes.Remove(recipe);
        await _context.SaveChangesAsync();

        return NoContent();
    }
    [HttpGet("search")]
public async Task<IActionResult> Search(string keyword)
{
    var recipes = await _context.Recipes
        .Where(r => r.RecipeName.Contains(keyword))
        .ToListAsync();

    return Ok(recipes);
}
[HttpGet("category/{id}")]
public async Task<IActionResult> GetByCategory(int id)
{
    var recipes = await _context.Recipes
        .Where(r => r.CategoryId == id)
        .ToListAsync();

    return Ok(recipes);
}
}