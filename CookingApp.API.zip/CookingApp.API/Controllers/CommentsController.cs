using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CookingApp.API.Data;
using CookingApp.API.Models;

namespace CookingApp.API.Controllers;

[ApiController]
[Route("api/comments")]
public class CommentsController : ControllerBase
{
    private readonly CookingAppDbContext _context;

    public CommentsController(CookingAppDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<IActionResult> GetComments()
    {
        return Ok(await _context.Comments.ToListAsync());
    }

    [HttpGet("recipe/{recipeId}")]
    public async Task<IActionResult> GetRecipeComments(int recipeId)
    {
        var comments = await _context.Comments
            .Where(c => c.RecipeId == recipeId)
            .ToListAsync();

        return Ok(comments);
    }

    [HttpPost]
    public async Task<IActionResult> AddComment(Comment comment)
    {
        comment.CreatedAt = DateTime.Now;

        _context.Comments.Add(comment);

        await _context.SaveChangesAsync();

        return Ok(comment);
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteComment(int id)
    {
        var comment =
            await _context.Comments.FindAsync(id);

        if (comment == null)
            return NotFound();

        _context.Comments.Remove(comment);

        await _context.SaveChangesAsync();

        return NoContent();
    }
}