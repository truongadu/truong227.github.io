using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CookingApp.API.Data;
using CookingApp.API.Models;
using CookingApp.API.Services;

namespace CookingApp.API.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController : ControllerBase
{
    private readonly CookingAppDbContext _context;
    private readonly JwtService _jwtService;

    public AuthController(
        CookingAppDbContext context,
        JwtService jwtService)
    {
        _context = context;
        _jwtService = jwtService;
    }

    // REGISTER
   [HttpPost("register")]
public async Task<IActionResult> Register([FromBody] RegisterRequest request)
{
    var existingUser = await _context.Users
        .FirstOrDefaultAsync(u => u.Email == request.Email);

    if (existingUser != null)
    {
        return BadRequest(new
        {
            Message = "Email đã tồn tại"
        });
    }

    var user = new User
    {
        FullName = request.FullName,
        Email = request.Email,
        PasswordHash = request.Password
    };

    _context.Users.Add(user);
    await _context.SaveChangesAsync();

    var token = _jwtService.GenerateToken(
        user.UserId,
        user.Email);

    return Ok(new
    {
        Message = "Đăng ký thành công",
        Token = token,
        UserId = user.UserId,
        FullName = user.FullName
    });
}

    // TEST
    [HttpGet("test")]
    public IActionResult Test()
    {
        return Ok("Auth API OK");
    }
    
}