using Microsoft.EntityFrameworkCore;
using CookingApp.API.Models;

namespace CookingApp.API.Data;

public class CookingAppDbContext : DbContext
{
    public CookingAppDbContext(DbContextOptions<CookingAppDbContext> options)
        : base(options)
    {
    }

    public DbSet<User> Users => Set<User>();
    public DbSet<Category> Categories => Set<Category>();
    public DbSet<Ingredient> Ingredients => Set<Ingredient>();
    public DbSet<Recipe> Recipes => Set<Recipe>();
    public DbSet<Favorite> Favorites => Set<Favorite>();
    public DbSet<Comment> Comments => Set<Comment>();
    public DbSet<Rating> Ratings => Set<Rating>();
    public DbSet<RecipeIngredient> RecipeIngredients => Set<RecipeIngredient>();
    
}