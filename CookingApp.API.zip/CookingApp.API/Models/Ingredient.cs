namespace CookingApp.API.Models;

public class Ingredient
{
    public int IngredientId { get; set; }
    public string IngredientName { get; set; } = "";
}