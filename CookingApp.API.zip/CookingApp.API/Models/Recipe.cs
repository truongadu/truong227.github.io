namespace CookingApp.API.Models;

public class Recipe
{
    public int RecipeId { get; set; }
    public string RecipeName { get; set; } = "";
    public string Description { get; set; } = "";
    public int CategoryId { get; set; }
    public int CookingTime { get; set; }
    public string ImageUrl { get; set; } = "";
}